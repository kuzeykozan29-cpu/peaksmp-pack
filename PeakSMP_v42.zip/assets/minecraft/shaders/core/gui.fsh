#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    // HELLFIRE: hide the vanilla scoreboard sidebar panel (pure black, alpha 0.3 for lines / 0.4 for the title)
    if (color.r + color.g + color.b < 0.004 && (abs(color.a - 0.298) < 0.006 || abs(color.a - 0.4) < 0.006)) {
        discard;
    }
    fragColor = color * ColorModulator;
}